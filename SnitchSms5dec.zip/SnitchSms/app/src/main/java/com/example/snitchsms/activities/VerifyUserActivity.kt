package com.example.snitchsms.activities

import android.os.Bundle
import android.util.Log
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.example.snitchsms.R
import com.example.snitchsms.databinding.ActivityVerifyUserBinding
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import java.util.concurrent.TimeUnit

class VerifyUserActivity : AppCompatActivity() {
    private lateinit var binding: ActivityVerifyUserBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVerifyUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Get Firebase Authentication instance
        val auth = FirebaseAuth.getInstance()

        val editTextPhoneNumber = findViewById<EditText>(R.id.editTextPhoneNumber)
//        val phoneNumber = "+1234567890"

        binding.btnSubmit.setOnClickListener {
            Log.d("VerifyUserActivity", "btnSubmit: click ")
            val phoneNumber = editTextPhoneNumber.text.toString().trim()

            if (phoneNumber.isNotEmpty()) {
                val options = PhoneAuthOptions.newBuilder(auth)
                    .setPhoneNumber(editTextPhoneNumber.text.toString())
                    .setTimeout(60L, TimeUnit.SECONDS)
                    .setActivity(this)
                    .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                        override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                            Log.d("VerifyUserActivity", "credential: $credential")
                            signInWithPhoneAuthCredential(credential)
                        }

                        override fun onVerificationFailed(e: FirebaseException) {
                            Log.d("VerifyUserActivity", "onVerificationFailed: ${e.message}")
                            // ...
                        }

                        // Additional callbacks as needed
                    })
                    .build()

                PhoneAuthProvider.verifyPhoneNumber(options)
            } else {
                // Handle the case where the phone number is empty
                // You might want to show an error message to the user
                // or prevent further processing.
            }
        }

    }

    private fun signInWithPhoneAuthCredential(credential: PhoneAuthCredential) {
        val auth = FirebaseAuth.getInstance()
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {

                    val user = task.result?.user
                    Log.d("VerifyUserActivity", "isSuccessful: $user")

                } else {

                }
            }
    }
}
