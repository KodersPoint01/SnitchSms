package com.example.snitchsms.recieptdata

data class ReceiptItem(
    val phoneNumber: String
)
