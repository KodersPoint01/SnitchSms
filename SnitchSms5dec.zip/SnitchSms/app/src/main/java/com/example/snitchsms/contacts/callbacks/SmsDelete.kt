package com.example.snitchsms.contacts.callbacks

interface SmsDelete {
    fun itemDelete(pos:Int)
    fun itemLongClick(pos:Int)


}