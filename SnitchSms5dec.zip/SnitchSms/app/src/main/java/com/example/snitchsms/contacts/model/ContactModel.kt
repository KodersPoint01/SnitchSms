package com.example.snitchsms.contacts.model

data class ContactModel(
    val contactName:String,
    val number:String
)
